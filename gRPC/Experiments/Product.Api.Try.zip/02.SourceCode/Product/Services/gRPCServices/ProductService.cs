﻿using Grpc.Core;
using Services.Interface;
using System.Threading.Tasks;
using TXC.Proto.Product;

namespace Services.gRPCServices
{
    public class ProductService : Product.ProductBase
    {
        private readonly ISelectProductsService _selectProductsService;        

        public ProductService(ISelectProductsService selectProductsService)
        {
            _selectProductsService = selectProductsService;            
        }

        public override async Task<ProtoBaseResponse> GetProducts(GetProductsRequest request, ServerCallContext context)
        {
            return await _selectProductsService.GetProducts(request);
        }

     
    }
}
