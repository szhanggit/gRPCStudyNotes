﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Services.Core;
using Services.Interface;

namespace Product.Api.Extensions
{
    public static class GRPCServiceExtension
    {
        public static IServiceCollection AddgRPCService(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<ISelectProductsService, SelectProductsService>();

            return services;
        }
    }
}
